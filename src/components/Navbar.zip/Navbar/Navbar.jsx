import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { HiMenuAlt3, HiX } from "react-icons/hi";

import ThemeSwitcher from "../ThemeSwitcher";
import "./navbar.css";

const navLinks = [
  { title: "Home", href: "#home" },
  { title: "About", href: "#about" },
  { title: "Skills", href: "#skills" },
  { title: "Projects", href: "#projects" },
  { title: "Education", href: "#education" },
  { title: "GitHub", href: "#github" },
  { title: "Contact", href: "#contact" },
];

function Navbar() {
  const [mobileMenu, setMobileMenu] = useState(false);
  const [active, setActive] = useState("Home");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 70);
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavigation = (title, href) => {
    setActive(title);
    setMobileMenu(false);

    const section = document.querySelector(href);

    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  return (
    <motion.header
      className={`navbar ${scrolled ? "navbar-scroll" : ""}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="navbar-container">

        {/* Logo */}

        <motion.div
          className="navbar-logo"
          whileHover={{ scale: 1.05 }}
          onClick={() => handleNavigation("Home", "#home")}
        >
          <span>G</span>OKULNATH
        </motion.div>

        {/* Desktop Menu */}

        <nav className="navbar-links">

          {navLinks.map((item) => (

            <button
              key={item.title}
              onClick={() =>
                handleNavigation(item.title, item.href)
              }
              className={
                active === item.title
                  ? "nav-link active-link"
                  : "nav-link"
              }
            >
              {item.title}
            </button>

          ))}

        </nav>

        {/* Right Side */}

        <div className="navbar-actions">

          <ThemeSwitcher />

          <a
            href="/resume.pdf"
            target="_blank"
            rel="noopener noreferrer"
            className="resume-btn"
          >
            Resume
          </a>

          <button
            className="mobile-btn"
            onClick={() =>
              setMobileMenu(!mobileMenu)
            }
          >
            {mobileMenu ? <HiX /> : <HiMenuAlt3 />}
          </button>

        </div>

      </div>

      {/* Mobile Menu */}

      <AnimatePresence>

        {mobileMenu && (

          <motion.div
            className="mobile-menu"

            initial={{
              opacity: 0,
              y: -20,
            }}

            animate={{
              opacity: 1,
              y: 0,
            }}

            exit={{
              opacity: 0,
              y: -20,
            }}
          >

            {navLinks.map((item) => (

              <button
                key={item.title}
                onClick={() =>
                  handleNavigation(
                    item.title,
                    item.href
                  )
                }
                className="mobile-link"
              >
                {item.title}
              </button>

            ))}

          </motion.div>

        )}

      </AnimatePresence>

    </motion.header>
  );
}

export default Navbar;