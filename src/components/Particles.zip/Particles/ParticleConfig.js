const particleConfig = {
  fullScreen: {
    enable: true,
    zIndex: -2,
  },

  background: {
    color: {
      value: "#050816",
    },
  },

  fpsLimit: 120,

  particles: {
    number: {
      value: 80,
      density: {
        enable: true,
      },
    },

    color: {
      value: [
        "#00E5FF",
        "#915EFF",
        "#FFFFFF",
      ],
    },

    links: {
      enable: true,
      distance: 150,
      color: "#00E5FF",
      opacity: 0.25,
      width: 1,
    },

    move: {
      enable: true,
      speed: 1,
      outModes: {
        default: "bounce",
      },
    },

    opacity: {
      value: 0.6,
    },

    shape: {
      type: "circle",
    },

    size: {
      value: {
        min: 1,
        max: 4,
      },
    },
  },

  interactivity: {
    events: {
      onHover: {
        enable: true,
        mode: "grab",
      },

      onClick: {
        enable: true,
        mode: "push",
      },
    },

    modes: {
      grab: {
        distance: 180,

        links: {
          opacity: 0.8,
        },
      },

      push: {
        quantity: 5,
      },
    },
  },

  detectRetina: true,
};

export default particleConfig;