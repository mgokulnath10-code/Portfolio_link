import { useEffect, useState } from "react";
import Particles, {
  initParticlesEngine,
} from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";

import particleConfig from "./ParticleConfig";

function ParticleBackground() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    initParticlesEngine(async (engine) => {
      await loadSlim(engine);
    }).then(() => setReady(true));
  }, []);

  if (!ready) return null;

  return (
    <Particles
      id="particles"
      options={particleConfig}
    />
  );
}

export default ParticleBackground;