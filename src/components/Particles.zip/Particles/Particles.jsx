import { useCallback } from "react";
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";
import { useEffect, useState } from "react";

function ParticleBackground() {
  const [init, setInit] = useState(false);

  useEffect(() => {
    initParticlesEngine(async (engine) => {
      await loadSlim(engine);
    }).then(() => {
      setInit(true);
    });
  }, []);

  const particlesLoaded = useCallback(async () => {}, []);

  if (!init) return null;

  return (
    <Particles
      id="particles"
      particlesLoaded={particlesLoaded}
      options={{
        fullScreen: {
          enable: true,
          zIndex: -1,
        },

        background: {
          color: {
            value: "#050816",
          },
        },

        fpsLimit: 120,

        particles: {
          number: {
            value: 80,
            density: {
              enable: true,
            },
          },

          color: {
            value: [
              "#00E5FF",
              "#915EFF",
              "#FFFFFF",
            ],
          },

          links: {
            enable: true,
            distance: 150,
            color: "#00E5FF",
            opacity: 0.25,
            width: 1,
          },

          move: {
            enable: true,
            speed: 1,
            outModes: {
              default: "bounce",
            },
          },

          opacity: {
            value: 0.6,
          },

          shape: {
            type: "circle",
          },

          size: {
            value: {
              min: 1,
              max: 4,
            },
          },
        },

        detectRetina: true,

        interactivity: {
          events: {
            onHover: {
              enable: true,
              mode: "grab",
            },

            onClick: {
              enable: true,
              mode: "push",
            },

            resize: true,
          },

          modes: {
            grab: {
              distance: 180,

              links: {
                opacity: 0.8,
              },
            },

            push: {
              quantity: 5,
            },
          },
        },
      }}
    />
  );
}

export default ParticleBackground;