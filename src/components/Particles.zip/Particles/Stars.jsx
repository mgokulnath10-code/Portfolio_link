import "./particles.css";

function Stars() {
  return (
    <div className="stars-wrapper">

      <span className="star s1"></span>
      <span className="star s2"></span>
      <span className="star s3"></span>
      <span className="star s4"></span>
      <span className="star s5"></span>
      <span className="star s6"></span>
      <span className="star s7"></span>
      <span className="star s8"></span>
      <span className="star s9"></span>
      <span className="star s10"></span>

    </div>
  );
}

export default Stars;