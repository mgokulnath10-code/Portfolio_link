import { motion } from "framer-motion";
import { statistics } from "./aboutData";

function Stats() {
  return (
    <section className="stats-container">

      {statistics.map((item, index) => (

        <motion.div
          key={index}
          className="stat-card"

          initial={{
            opacity: 0,
            y: 50,
          }}

          whileInView={{
            opacity: 1,
            y: 0,
          }}

          viewport={{
            once: true,
          }}

          transition={{
            delay: index * 0.15,
            duration: 0.6,
          }}

          whileHover={{
            scale: 1.05,
            y: -8,
          }}
        >

          <h2 className="stat-number">
            {item.number}
          </h2>

          <p className="stat-label">
            {item.label}
          </p>

        </motion.div>

      ))}

    </section>
  );
}

export default Stats;