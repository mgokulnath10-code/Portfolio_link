import { FaCode, FaLaptopCode, FaRocket, FaLightbulb } from "react-icons/fa";

const cards = [
  {
    icon: <FaCode />,
    title: "Frontend",
    text: "Building responsive, modern and user-friendly web interfaces.",
  },
  {
    icon: <FaLaptopCode />,
    title: "Backend",
    text: "Developing scalable APIs and full-stack applications.",
  },
  {
    icon: <FaRocket />,
    title: "Projects",
    text: "Creating real-world applications using modern technologies.",
  },
  {
    icon: <FaLightbulb />,
    title: "Learning",
    text: "Always exploring new tools and improving my development skills.",
  },
];

function AboutCards() {
  return (
    <div className="about-cards">
      {cards.map((card, index) => (
        <div className="about-card" key={index}>
          <div className="card-icon">
            {card.icon}
          </div>

          <h3>{card.title}</h3>

          <p>{card.text}</p>
        </div>
      ))}
    </div>
  );
}

export default AboutCards;