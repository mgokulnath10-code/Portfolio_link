import {
  FaCode,
  FaLaptopCode,
  FaGraduationCap,
  FaAward,
} from "react-icons/fa";

export const aboutCards = [
  {
    id: 1,
    icon: FaLaptopCode,
    title: "Web Development",
    description:
      "Build modern and responsive web applications using React, JavaScript and Node.js.",
  },

  {
    id: 2,
    icon: FaCode,
    title: "Programming",
    description:
      "Strong knowledge in Java, Python, C++, JavaScript and Data Structures.",
  },

  {
    id: 3,
    icon: FaGraduationCap,
    title: "Computer Science",
    description:
      "Computer Science Engineering student passionate about software development.",
  },

  {
    id: 4,
    icon: FaAward,
    title: "Continuous Learning",
    description:
      "Always learning new technologies and improving development skills.",
  },
];

export const statistics = [
  {
    number: "8.3",
    label: "CGPA",
  },

  {
    number: "200+",
    label: "Problems Solved",
  },

  {
    number: "3+",
    label: "Projects",
  },

  {
    number: "4+",
    label: "Certifications",
  },
];