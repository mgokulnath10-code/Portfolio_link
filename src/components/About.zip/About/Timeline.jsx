import { motion } from "framer-motion";

const timeline = [
  {
    year: "2023",
    title: "Started B.E Computer Science",
    company: "Gnanamani College of Technology",
    description:
      "Started my Computer Science Engineering journey and began learning programming fundamentals.",
  },

  {
    year: "2024",
    title: "Web Development",
    company: "React & JavaScript",
    description:
      "Started building responsive websites using HTML, CSS, JavaScript and React.",
  },

  {
    year: "2025",
    title: "Full Stack Development",
    company: "React • Node.js • MongoDB",
    description:
      "Built full-stack projects using React, Node.js, Express and MongoDB.",
  },

  {
    year: "2027",
    title: "Graduation",
    company: "Bachelor of Engineering",
    description:
      "Expected graduation with strong programming and software development skills.",
  },
];

function Timeline() {
  return (
    <section className="timeline-section">

      <h2 className="timeline-heading">
        Education Timeline
      </h2>

      <div className="timeline">

        {timeline.map((item, index) => (

          <motion.div
            key={index}
            className="timeline-item"

            initial={{
              opacity: 0,
              x: index % 2 === 0 ? -80 : 80,
            }}

            whileInView={{
              opacity: 1,
              x: 0,
            }}

            viewport={{
              once: true,
            }}

            transition={{
              duration: 0.6,
              delay: index * 0.2,
            }}
          >

            <div className="timeline-dot"></div>

            <div className="timeline-content">

              <span className="timeline-year">
                {item.year}
              </span>

              <h3>{item.title}</h3>

              <h4>{item.company}</h4>

              <p>{item.description}</p>

            </div>

          </motion.div>

        ))}

      </div>

    </section>
  );
}

export default Timeline;