import { motion } from "framer-motion";

function AboutContent() {
  return (
    <div className="about-content">
      <motion.span
        className="section-subtitle"
        initial={{ opacity: 0, x: -40 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
      >
        About Me
      </motion.span>

      <motion.h2
        className="section-title"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        Passionate Full Stack Developer
      </motion.h2>

      <motion.p
        className="about-description"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        viewport={{ once: true }}
      >
        Hello! I'm{" "}
        <span className="highlight">Gokulnath</span>, a Computer
        Science Engineering student passionate about building
        modern web applications with clean UI and responsive
        design.
      </motion.p>

      <motion.p
        className="about-description"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        viewport={{ once: true }}
      >
        I enjoy working with{" "}
        <span className="highlight">
          React, JavaScript, Node.js, Python
        </span>{" "}
        and continuously improve my problem-solving and software
        development skills through real-world projects.
      </motion.p>
    </div>
  );
}

export default AboutContent;