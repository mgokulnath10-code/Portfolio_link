import { motion } from "framer-motion";
import { socialLinks } from "./heroData";

function SocialLinks() {
  return (
    <motion.div
      className="social-links"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        delay: 1,
        duration: 0.6,
      }}
    >
      {socialLinks.map((item, index) => {
        const Icon = item.icon;

        return (
          <motion.a
            key={index}
            href={item.url}
            target="_blank"
            rel="noopener noreferrer"
            className="social-icon"
            whileHover={{
              y: -8,
              scale: 1.15,
              rotate: 5,
            }}
            whileTap={{
              scale: 0.9,
            }}
            transition={{
              type: "spring",
              stiffness: 300,
            }}
          >
            <Icon />
          </motion.a>
        );
      })}
    </motion.div>
  );
}

export default SocialLinks;