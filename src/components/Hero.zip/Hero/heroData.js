import {
  FaGithub,
  FaLinkedin,
  FaEnvelope,
} from "react-icons/fa";

export const heroData = {
  greeting: "Hello, I'm",

  name: "M GOKULNATH",

  titles: [
    "Full Stack Developer",
    "React Developer",
    "Java Developer",
    "Computer Science Student",
  ],

  description:
    "Passionate Computer Science student building modern web applications using React, Node.js, Java, Python and MongoDB.",

  resume: "/resume.pdf",

  profileImage: "/profile.png",
};

export const socialLinks = [
  {
    icon: FaGithub,
    url: "https://github.com/mgokulnath10-code",
  },
  {
    icon: FaLinkedin,
    url: "https://linkedin.com/in/gokulnath-m-2mg",
  },
  {
    icon: FaEnvelope,
    url: "mailto:m.gokulnath10@email.com",
  },
];