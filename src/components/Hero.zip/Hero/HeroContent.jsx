import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";

import { heroData } from "./heroData";

import HeroButtons from "./HeroButtons";

import SocialLinks from "./SocialLinks";

function HeroContent() {
  return (
    <motion.div
      className="hero-content"
      initial={{ opacity: 0, x: -80 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{
        duration: 0.8,
      }}
    >
      <motion.p
        className="hero-greeting"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          delay: 0.2,
        }}
      >
        👋 {heroData.greeting}
      </motion.p>

      <motion.h1
        className="hero-name"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          delay: 0.3,
        }}
      >
        {heroData.name}
      </motion.h1>

      <TypeAnimation
        sequence={[
          heroData.titles[0],
          2000,

          heroData.titles[1],
          2000,

          heroData.titles[2],
          2000,

          heroData.titles[3],
          2000,
        ]}
        wrapper="h2"
        speed={40}
        repeat={Infinity}
        className="hero-title"
      />

      <motion.p
        className="hero-description"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{
          delay: 0.5,
        }}
      >
        {heroData.description}
      </motion.p>

      <HeroButtons />

      <SocialLinks />

    </motion.div>
  );
}

export default HeroContent;