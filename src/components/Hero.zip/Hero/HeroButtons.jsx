import { motion } from "framer-motion";
import { FaDownload, FaPaperPlane } from "react-icons/fa";

import { heroData } from "./heroData";

function HeroButtons() {
  const scrollToContact = () => {
    const section = document.getElementById("contact");

    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  return (
    <motion.div
      className="hero-buttons"
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        delay: 0.7,
        duration: 0.6,
      }}
    >
      <motion.button
        className="primary-btn"
        whileHover={{
          scale: 1.05,
          y: -4,
        }}
        whileTap={{
          scale: 0.95,
        }}
        onClick={scrollToContact}
      >
        <FaPaperPlane />

        Hire Me
      </motion.button>

      <motion.a
        href={heroData.resume}
        download
        className="secondary-btn"
        whileHover={{
          scale: 1.05,
          y: -4,
        }}
        whileTap={{
          scale: 0.95,
        }}
      >
        <FaDownload />

        Download Resume
      </motion.a>
    </motion.div>
  );
}

export default HeroButtons;