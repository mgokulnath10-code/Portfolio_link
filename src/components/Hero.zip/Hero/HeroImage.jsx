import { motion } from "framer-motion";
import { heroData } from "./heroData";

function HeroImage() {
  return (
    <motion.div
      className="hero-image-container"
      initial={{
        opacity: 0,
        scale: 0.8,
        x: 100,
      }}
      animate={{
        opacity: 1,
        scale: 1,
        x: 0,
      }}
      transition={{
        duration: 0.8,
      }}
    >
      {/* Glow Circle */}

      <div className="image-glow"></div>

      {/* Floating Circle */}

      <div className="image-ring"></div>

      {/* Profile */}

      <motion.img
        src={heroData.profileImage}
        alt={heroData.name}
        className="hero-image"
        animate={{
          y: [0, -15, 0],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        whileHover={{
          scale: 1.05,
          rotate: 2,
        }}
      />

    </motion.div>
  );
}

export default HeroImage;