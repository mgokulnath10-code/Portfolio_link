import { motion } from "framer-motion";
import { FaChevronDown } from "react-icons/fa";

function ScrollIndicator() {
  const scrollToAbout = () => {
    const section = document.getElementById("about");

    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  return (
    <motion.div
      className="scroll-indicator"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        delay: 1.5,
        duration: 0.8,
      }}
      onClick={scrollToAbout}
    >
      <div className="mouse">
        <motion.div
          className="mouse-wheel"
          animate={{
            y: [0, 10, 0],
          }}
          transition={{
            repeat: Infinity,
            duration: 1.5,
          }}
        />
      </div>

      <motion.div
        animate={{
          y: [0, 8, 0],
        }}
        transition={{
          repeat: Infinity,
          duration: 1.5,
        }}
      >
        <FaChevronDown />
      </motion.div>
    </motion.div>
  );
}

export default ScrollIndicator;