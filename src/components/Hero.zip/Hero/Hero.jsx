function Hero() {
  return (
    <section
      style={{
        height: "100vh",
        background: "#050816",
        color: "white",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "40px",
      }}
    >
      Hero Working
    </section>
  );
}

export default Hero;